To compile the help file you will need to install the Help workshop.

This is shipped with the service pack installs but you will need to install it seperately