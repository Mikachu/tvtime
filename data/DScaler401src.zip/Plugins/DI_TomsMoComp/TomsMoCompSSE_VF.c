#define IS_SSE
#define SSE_TYPE SSE
#define USE_VERTICAL_FILTER 
#define FUNCT_NAME AvisynthTomsMoComp_SSE_VF
#include "TomsMoCompAllAvisynth.inc"