#define IS_SSE
#define SSE_TYPE SSE
#define FUNCT_NAME AvisynthTomsMoComp_SSE
#include "TomsMoCompAllAvisynth.inc"


