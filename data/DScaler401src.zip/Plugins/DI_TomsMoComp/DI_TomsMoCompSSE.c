#define USE_FOR_DSCALER
#define IS_SSE
#define SSE_TYPE SSE
#define FUNCT_NAME DeinterlaceTomsMoComp_SSE
#include "TomsMoCompAll.inc"


