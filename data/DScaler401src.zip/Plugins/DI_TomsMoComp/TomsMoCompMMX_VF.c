#define IS_MMX
#define SSE_TYPE MMX
#define USE_VERTICAL_FILTER
#define FUNCT_NAME AvisynthTomsMoComp_MMX_VF
#include "TomsMoCompAllAvisynth.inc"
