#define IS_MMX
#define SSE_TYPE MMX
#define FUNCT_NAME AvisynthTomsMoComp_MMX
#include "TomsMoCompAllAvisynth.inc"
