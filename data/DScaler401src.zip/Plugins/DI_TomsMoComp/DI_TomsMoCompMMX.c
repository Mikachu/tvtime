#define USE_FOR_DSCALER
#define IS_MMX
#define SSE_TYPE MMX
#define FUNCT_NAME DeinterlaceTomsMoComp_MMX
#include "TomsMoCompAll.inc"
