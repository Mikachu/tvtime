#define USE_FOR_DSCALER
#define IS_SSE2
#define SSE_TYPE SSE
#define FUNCT_NAME DeinterlaceTomsMoComp_SSE2
#include "TomsMoCompAll.inc"


