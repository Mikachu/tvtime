#define IS_3DNOW
#define SSE_TYPE 3DNOW
#define FUNCT_NAME AvisynthTomsMoComp_3DNOW
#include "TomsMoCompAllAvisynth.inc"
