#define IS_3DNOW
#define SSE_TYPE 3DNOW
#define USE_VERTICAL_FILTER
#define FUNCT_NAME AvisynthTomsMoComp_3DNOW_VF
#include "TomsMoCompAllAvisynth.inc"
