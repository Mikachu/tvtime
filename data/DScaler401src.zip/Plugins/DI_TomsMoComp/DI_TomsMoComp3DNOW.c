#define USE_FOR_DSCALER
#define IS_3DNOW
#define SSE_TYPE 3DNOW
#define FUNCT_NAME DeinterlaceTomsMoComp_3DNOW
#include "TomsMoCompAll.inc"
