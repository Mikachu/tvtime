As of DScaler 4.0 DScaler uses the Open Source but not GPL InnoSetup
Get it from

http://www.jrsoftware.org/isinfo.php

The file we use to build the installer id DScaler.iss

There is also an old test installer that uses Visual Studio Installer 1.1
http://msdn.microsoft.com/vstudio/downloads/vsi11/download.asp